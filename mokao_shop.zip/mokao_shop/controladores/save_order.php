<?php
$conn = new mysqli("localhost", "usuario", "password", "tienda_franelas");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $estilo = $_POST['estilo']; 
    $precio = $_POST['precio'];
    $imagen = $_POST['imagen']; // String Base64

    $stmt = $conn->prepare("INSERT INTO pedidos (estilo, precio_total, imagen_diseno) VALUES (?, ?, ?)");
    $stmt->bind_param("sds", $estilo, $precio, $imagen);
    
    if ($stmt->execute()) {
        echo "Orden procesada";
    } else {
        echo "Error";
    }
}
?>