const PRINT_TECHNIQUE_BASE = 5;

const shirtModel = document.getElementById("shirt-model");
const colorLabel = document.getElementById("color-label");
const designLayer = document.getElementById("design-layer");
const uploadInput = document.getElementById("file-input");
const userUpload = document.getElementById("user-upload");
const designPlaceholder = document.getElementById("design-placeholder");
const fileNameLabel = document.getElementById("file-name");
const printSizeInput = document.getElementById("print-size");
const printSizeValue = document.getElementById("print-size-value");
const saveFeedback = document.getElementById("save-feedback");
const summaryColor = document.getElementById("summary-color");

function getCheckedInput(name) {
    return document.querySelector(`input[name="${name}"]:checked`);
}

function getStyleLabel(value) {
    const labels = {
        clasica: "Clásica", 
        oversize: "Oversize",
        boxy: "Boxy Fit"
    };

    return labels[value] || value;
}

function getPositionLabel(value) {
    const labels = {
        center: "Frontal",
        "top-left": "Pecho",
        full: "Maxi print"
    };

    return labels[value] || value;
}

function updateShirtColor() {
    const selectedColor = getCheckedInput("color");
    const color = selectedColor.value;
    const label = selectedColor.dataset.label || color;
    document.documentElement.style.setProperty("--shirt-color", color);
    colorLabel.textContent = label;
    summaryColor.textContent = label;
}

function updateShirtStyle() {
    const selectedStyle = getCheckedInput("estilo");
    const styleValue = selectedStyle.value;

    shirtModel.classList.remove("shirt-clasica", "shirt-oversize", "shirt-boxy");
    shirtModel.classList.add(`shirt-${styleValue}`);

    document.getElementById("summary-style").textContent = getStyleLabel(styleValue);
}

function updateDesignPosition() {
    const selectedPosition = getCheckedInput("print-position");
    const positionValue = selectedPosition.value;

    designLayer.classList.remove("position-center", "position-top-left", "position-full");
    designLayer.classList.add(`position-${positionValue}`);
    designLayer.dataset.position = positionValue;

    document.getElementById("summary-position").textContent = getPositionLabel(positionValue);
}

function updateDesignScale() {
    const scaleValue = Number(printSizeInput.value);
    const scale = scaleValue / 100;

    designLayer.style.transform = `translate(-50%, -50%) scale(${scale})`;
    printSizeValue.textContent = `${scaleValue}%`;
}

function updateSelectedSize() {
    document.getElementById("summary-size").textContent = getCheckedInput("talla").value;
}

function updatePrice() {
    const selectedStyle = getCheckedInput("estilo");
    const selectedSize = getCheckedInput("talla");
    const selectedPosition = getCheckedInput("print-position");
    const printCoverageFee = Math.max(0, Math.round((Number(printSizeInput.value) - 100) / 15));

    const basePrice = Number(selectedStyle.dataset.price);
    const sizeExtra = Number(selectedSize.dataset.extra);
    const positionExtra = Number(selectedPosition.dataset.extra);
    const printCost = PRINT_TECHNIQUE_BASE + positionExtra + printCoverageFee;
    const total = basePrice + sizeExtra + printCost;

    document.getElementById("total-price").textContent = total;
    document.getElementById("breakdown-base").textContent = `$${basePrice}`;
    document.getElementById("breakdown-size").textContent = `$${sizeExtra}`;
    document.getElementById("breakdown-print").textContent = `$${printCost}`;
}

function handleUpload(event) {
    const [file] = event.target.files;

    if (!file) {
        fileNameLabel.textContent = "Aún no has subido una imagen";
        userUpload.style.display = "none";
        designPlaceholder.style.display = "block";
        return;
    }

    const reader = new FileReader();
    reader.onload = function(loadEvent) {
        userUpload.src = loadEvent.target.result;
        userUpload.style.display = "block";
        designPlaceholder.style.display = "none";
        fileNameLabel.textContent = file.name;
    };
    reader.readAsDataURL(file);
}

function attachControlListeners() {
    document.querySelectorAll('input[name="estilo"]').forEach((input) => {
        input.addEventListener("change", () => {
            updateShirtStyle();
            updatePrice();
        });
    });

    document.querySelectorAll('input[name="talla"]').forEach((input) => {
        input.addEventListener("change", () => {
            updateSelectedSize();
            updatePrice();
        });
    });

    document.querySelectorAll('input[name="print-position"]').forEach((input) => {
        input.addEventListener("change", () => {
            updateDesignPosition();
            updatePrice();
        });
    });

    document.querySelectorAll('input[name="color"]').forEach((input) => {
        input.addEventListener("change", () => {
            updateShirtColor();
            updatePrice();
        });
    });

    printSizeInput.addEventListener("input", () => {
        updateDesignScale();
        updatePrice();
    });
    uploadInput.addEventListener("change", handleUpload);
}

function initialiseCustomizer() {
    updateShirtColor();
    updateShirtStyle();
    updateDesignPosition();
    updateDesignScale();
    updateSelectedSize();
    updatePrice();
    attachControlListeners();
}

function saveDesign() {
    const area = document.getElementById("preview-area");
    const selectedStyle = getCheckedInput("estilo").value;
    const selectedSize = getCheckedInput("talla").value;
    const selectedPosition = getCheckedInput("print-position").value;

    if (typeof html2canvas !== "function") {
        saveFeedback.textContent = "La librería para capturar la vista previa no está disponible en este momento.";
        return;
    }

    saveFeedback.textContent = "Preparando la vista previa para guardar...";

    html2canvas(area, { backgroundColor: null }).then((canvas) => {
        const base64image = canvas.toDataURL("image/png");
        const formData = new FormData();

        const selectedColor = getCheckedInput("color");
        formData.append("imagen", base64image);
        formData.append("precio", document.getElementById("total-price").textContent);
        formData.append("estilo", selectedStyle);
        formData.append("talla", selectedSize);
        formData.append("posicion", selectedPosition);
        formData.append("color", selectedColor?.value || "#7a5034");

        return fetch("controladores/save_order.php", {
            method: "POST",
            body: formData
        });
    }).then((response) => response.text())
      .then(() => {
          saveFeedback.textContent = "Pedido guardado con éxito. Ya tienes una referencia de cotización.";
      })
      .catch(() => {
          saveFeedback.textContent = "No se pudo guardar el diseño. Revisa la conexión del backend.";
      });
}

initialiseCustomizer();
